
MDM Cherokee Flute v1.0.1
=========================

Here I have sampled my own Cherokee flute I crafted myself for myself.
It is very simple Cherokee style flute, of the low E (E4) pentatonic minor (one octave), and of a fine breathy sound. This is simple version for Kontakt.

Mića de Mijatović y Senić
16:21 2024-09-14 Sat